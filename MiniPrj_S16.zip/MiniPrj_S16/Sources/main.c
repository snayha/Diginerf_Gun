/*
************************************************************************
 ECE 362 - Mini-Project C Source File - Spring 2016
***********************************************************************
	 	   			 		  			 		  		
 Team ID: < 4 >

 Project Name: < DigiNerf Gun >

 Team Members:

   - Team/Doc Leader: < ? >      Signature: ___Charles Li_________
   
   - Software Leader: < ? >      Signature: ___Ryan McBee_________

   - Interface Leader: < ? >     Signature: ___Luke McBee_________

   - Peripheral Leader: < ? >    Signature: ___Swati Garg_________


 Academic Honesty Statement:  In signing above, we hereby certify that we 
 are the individuals who created this HC(S)12 source file and that we have
 not copied the work of any other student (past or present) while completing 
 it. We understand that if we fail to honor this agreement, we will receive 
 a grade of ZERO and be subject to possible disciplinary action.

***********************************************************************

 The objective of this Mini-Project is to ...
 
 We are modifying a nerf gun so we can improve the ergonomics of a blaster. We will be 
 using a SPI shift register to control LED outputs. The LED will track the location of 
 the ammo in the clip and the ammo shooting out of the nerf gun. To receive user input, 
 we will include digital inputs by using buttons on the gun. There will also be an analog 
 to digital converter, so we can have multiple readouts on the LCD display. The readouts 
 will include some configurable settings and information read outs, such as speed of 
 the ammo. We will also using a PWM motor to control the speed of the ammo. 


***********************************************************************

 List of project-specific success criteria (functionality that will be
 demonstrated):

 1. Variable Speed using PWM motor

 2. LED output controls w/ SPI shift register

 3. Different bullet shoot outs (1, 3, automatic) using push buttons

 4. LCD display (speed, type of shootout)

 5.

***********************************************************************

  Date code started: < 4/18/16 >

  Update history (add an entry every time a significant change is made):

  Date: < ? >  Name: < ? >   Update: < ? >

  Date: < ? >  Name: < ? >   Update: < ? >

  Date: < ? >  Name: < ? >   Update: < ? >


***********************************************************************
*/

#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include <mc9s12c32.h>

#define LED1ON     PTT = (PTT | (1 << 7))
#define LED1OFF    PTT = (PTT & (0x7F))
#define LED1TOGGLE PTT = (PTT ^ (1 << 7))

#define LED2ON     PTT = (PTT | (1 << 6))
#define LED2OFF    PTT = (PTT & (0xBF))
#define LED2TOGGLE PTT = (PTT ^ (1 << 6))

#define RSON     PTT = (PTT | RS)
#define RSOFF    PTT = (PTT & (0xFF - RS))
#define RSTOGGLE PTT = (PTT ^ RS)

#define RWON     PTT = (PTT | RW)
#define RWOFF    PTT = (PTT & (0xFF - RW))
#define RWTOGGLE PTT = (PTT ^ RW)

#define CLKON     PTT = (PTT | LCDCLK)
#define CLKOFF    PTT = (PTT & (0xFF - LCDCLK))
#define CLKTOGGLE PTT = (PTT ^ LCDCLK)

#define FLY_WHEEL   PWMDTY0
#define PISTON      PWMDTY1

#define TRIGGER PTAD_PTAD4
#define CLIP_IN PTAD_PTAD5
#define PISTON_BACK PTAD_PTAD6
#define SETTINGS PTAD_PTAD7

#define START_ADC ATDCTL5 = 0x10;while(!ATDSTAT0_SCF) {}
#define FlY_WHEEL_SPEED ATDDR0H;
#define PISTON_SPEED ATDDR1H;

#define LATCHON      PTT = (PTT | (1 << 5))
#define LATCHOFF    PTT = (PTT & (0xDF))
#define LATCHTOGGLE PTT = (PTT ^ (1 << 5))

#define MOTOR_REV PORTE_BIT0


/* All functions after main should be initialized here */
char inchar(void);
void outchar(char x);
void rdisp(void);
void shiftout(char);	// LCD drivers (written previously)
void lcdwait(void);
void send_byte(char);
void send_i(char);
void chgline(char);
void print_c(char);
void pmsglcd(char[]);

/* Variable declarations */
int i = 0;
int trigger = 0;
int clipin = 0;
int piston = 0;
int motorRev = 0;
int firingState = 0;
int fireRate = 0;

int pistonHasFired = 0;

int time = 0;
   	   			 		  			 		       

/* Special ASCII characters */
#define CR 0x0D		// ASCII return�
#define LF 0x0A		// ASCII new line�

/* LCD COMMUNICATION BIT MASKS (note - different than previous labs) */
#define RS 0x04		// RS pin mask (PTT[4])
#define RW 0x08		// R/W pin mask (PTT[5])
#define LCDCLK 0x10	// LCD EN/CLK pin mask (PTT[6])

/* LCD INSTRUCTION CHARACTERS */
#define LCDON 0x0F	// LCD initialization command
#define LCDCLR 0x01	// LCD clear display command
#define TWOLINE 0x38	// LCD 2-line enable command
#define CURMOV 0xFE	// LCD cursor move instruction
#define LINE1 = 0x80	// LCD line 1 cursor position
#define LINE2 = 0xC0	// LCD line 2 cursor position

	 	   		
/*	 	   		
***********************************************************************
 Initializations
***********************************************************************
*/

void  initializations(void) {

/* Set the PLL speed (bus clock = 24 MHz) */
  CLKSEL = CLKSEL & 0x80; //; disengage PLL from system
  PLLCTL = PLLCTL | 0x40; //; turn on PLL
  SYNR = 0x02;            //; set PLL multiplier
  REFDV = 0;              //; set PLL divider
  while (!(CRGFLG & 0x08)){  }
  CLKSEL = CLKSEL | 0x80; //; engage PLL

/* Disable watchdog timer (COPCTL register) */
  COPCTL = 0x40   ; //COP off; RTI and COP stopped in BDM-mode

/* Initialize asynchronous serial port (SCI) for 9600 baud, interrupts off initially */
  SCIBDH =  0x00; //set baud rate to 9600
  SCIBDL =  0x9C; //24,000,000 / 16 / 156 = 9600 (approx)  
  SCICR1 =  0x00; //$9C = 156
  SCICR2 =  0x0C; //initialize SCI for program-driven operation
  DDRB   =  0x10; //set PB4 for output mode
  PORTB  =  0x10; //assert DTR pin on COM port

/* Initialize peripherals */
   
   //create internal pull up resistors
   PERAD_PERAD4 = 1;
   PERAD_PERAD5 = 1;
   PERAD_PERAD6 = 1;
   PERAD_PERAD7 = 1;
          
/* Initialize interrupts */
	      
	
	
/* 
   Initialize TIM Ch 7 (TC7) for periodic interrupts every 10.0 ms  
    - Enable timer subsystem��   ����  � ������   �� 
    - Set channel 7 for output compare
    - Set appropriate pre-scale factor and enable counter reset after OC7
    - Set up channel 7 to generate 10 ms interrupt rate
    - Initially disable TIM Ch 7 interrupts	 	   			 		  			 		  		
*/	 	   			 		  			 		  		
   TSCR1 = 0x80;
   TSCR2 = 0x0C;
   TIOS = 0x80;
   TIE = 0x80;
   TC7 = 1500;

/*
 Initialize the PWM unit to produce a signal with the following
 characteristics on PWM output channel 3:
   - sampling frequency of approximately 100 Hz
   - left-aligned, negative polarity
   - period register = $FF (yielding a duty cycle range of 0% to 100%,
     for duty cycle register values of $00 to $FF 
   - duty register = $00 (motor initially stopped)
��   ����  � ������   �� 
 IMPORTANT: Need to set MODRR so that PWM Ch 1 is routed to port pin PT0
*/ 	   			 		  			 		  		
   MODRR = 0x03;
   PWME = 0x03;
   PWMPOL = 0x03;
   PWMCTL = 0x00;
   PWMCAE = 0x00;
   PWMCLK = 0x00;
   PWMPRCLK = 0x01;
   PWMSCLA = 117; 
   
   PWMPER0 = 0xFF;
   PWMDTY0 = 0x00;
   
   PWMPER1 = 0xFF;
   PWMDTY1 = 0x00; 

/* Initialize the ATD to sample a D.C. input voltage (range: 0 to 5V)
 on Channel 0 (connected to a 10K-ohm potentiometer). The ATD should
 be operated in a program-driven (i.e., non-interrupt driven), normal
 flag clear mode using nominal sample time/clock prescaler values,
 8-bit,  unsigned, non-FIFO mode.
��   ����  � ������   �� 
 Note: Vrh (the ATD reference high voltage) is connected to 5 VDC and
       Vrl (the reference low voltage) is connected to GND on the 
       9S12C32 kit.  An input of 0v will produce output code $00,
       while an input of 5.00 volts will produce output code $FF
*/	 	   			 		  			 		  		
   DDRAD = 0; 
   ATDDIEN = 0xF0;
   ATDCTL2 = 0x80;
   ATDCTL3 = 0x10;
   ATDCTL4 = 0x85; 

/*
  Initialize the RTI for an 2.048 ms interrupt rate
*/
   CRGINT = CRGINT | 0x80; 
   RTICTL = 0x1F;    
  
/*
  Initialize SPI for baud rate of 6 Mbs, MSB first
  (note that R/S, R/W', and LCD clk are on different PTT pins)
*/
  DDRM   = 0xFF;
  SPICR1 = 0x50;
  SPICR2 = 0x00;
  SPIBR  = 0x01;

/* Initialize digital I/O port pins */
   DDRT = 0xFC; 

/* 
   Initialize the LCD
     - pull LCDCLK high (idle)
     - pull R/W' low (write state)
     - turn on LCD (LCDON instruction)
     - enable two-line mode (TWOLINE instruction)
     - clear LCD (LCDCLR instruction)
     - wait for 2ms so that the LCD can wake up     
*/ 
	 CLKON;
   RWOFF;
  /* send_i(LCDON);
   send_i(TWOLINE);
   send_i(LCDCLR);
   lcdwait();*/	   			 		  			 		  		   
}

	 		  			 		  		
/*	 		  			 		  		
***********************************************************************
Main
***********************************************************************
*/
void main(void) {
  DisableInterrupts
	initializations(); 		  			 		  		
	EnableInterrupts;
   

 for(;;) {
  
/* < start of your main loop > */ 
  /* LATCHOFF;
  
    lcdwait();  
  
    shiftout(0xFF);
   
    lcdwait();
    
    LATCHON; 
    
    lcdwait();
    
    */;
      LED2ON;
      
      
      if(PISTON_BACK)
        LED1ON;
      
      else
        LED1OFF; 

    
    //buttons work
    /*if(1){
      LED2ON;  //blue led on
    
    
      START_ADC;
      FLY_WHEEL = FlY_WHEEL_SPEED;
      
      if(!trigger) {
       // LED1ON;  //orange on
        PISTON = 255;
        firingState = 1;  
        fireRate = 1;
      } else {
       // LED1OFF;  //orange off
        
        if(piston)
          PISTON = 255;
        else
          PISTON = 0;
      }
    } 
    else{
      LED2OFF;    //blue led off
    }*/
     
   } /* loop forever */
   
}   /* do not leave main */




/*
***********************************************************************   ����  � ������   �� 
 RTI interrupt service routine: RTI_ISR
************************************************************************
*/

interrupt 7 void RTI_ISR(void)
{
  	// clear RTI interrupt flagt 
  	CRGFLG = CRGFLG | 0x80; 
    
    
    
    if(TRIGGER){
      trigger = 0;    
    } else{
      trigger = 1;  
    }
    
    if(CLIP_IN){
      clipin = 0;    
    } else{
      clipin = 1;
    }
    
    if(PISTON){
      piston = 0;     
    } else{
      piston = 1; 
    }   
    
    if(MOTOR_REV){
        motorRev = 0; 
    } else{
       motorRev = 1;   
    }

}

/*
***********************************************************************   ����  � ������   �� 
  TIM interrupt service routine	  		
***********************************************************************
*/

interrupt 15 void TIM_ISR(void)
{
  	// clear TIM CH 7 interrupt flag 
 	TFLG1 = TFLG1 | 0x80; 
 	  
    time++;
    
}

/*
***********************************************************************   ����  � ������   �� 
  SCI interrupt service routine		 		  		
***********************************************************************
*/

interrupt 20 void SCI_ISR(void)
{
 


}

/*
***********************************************************************
  shiftout: Transmits the character x to external shift 
            register using the SPI.  It should shift MSB first.  
            MISO = PM[4]
            SCK  = PM[5]
***********************************************************************
*/
void rdisp() 
{    
     //FIREMODE
     //SPEED
     //F
}

/*
***********************************************************************
  lcdwait: Delay for approx 1 ms
***********************************************************************
*/

void lcdwait()
{
  for(i=0; i < 8000; i++) 
  {
    asm 
    {
      nop; 
    }
  } 
}

/*
***********************************************************************
  shiftout: Transmits the character x to external shift 
            register using the SPI.  It should shift MSB first.  
            MISO = PM[4]
            SCK  = PM[5]
***********************************************************************
*/
 
void shiftout(char x)

{
  // test the SPTEF bit: wait if 0; else, continue
  // write data x to SPI data register
  // wait for 30 cycles for SPI data to shift out 
  //LATCHOFF;
  if(SPISR & 0x10) 
  {
    SPIDR = x;
    for(i=0; i<1000; i++) 
    {
      asm 
      {
        nop; 
      }
    }
  }
  
  //LATCHON;
}

/*
*********************************************************************** 
  send_byte: writes character x to the LCD
***********************************************************************
*/

void send_byte(char x)
{
  // shift out character
  // pulse LCD clock line low->high->low
  // wait 2 ms for LCD to process data
  shiftout(x);
  CLKOFF;
  CLKON;
  CLKOFF;
  lcdwait();
}

/*
***********************************************************************
  send_i: Sends instruction byte x to LCD  
***********************************************************************
*/

void send_i(char x)
{
  // set the register select line low (instruction data)
  // send byte
  RSOFF;
  send_byte(x);
}

/*
***********************************************************************
  chgline: Move LCD cursor to position x
  NOTE: Cursor positions are encoded in the LINE1/LINE2 variables
***********************************************************************
*/

void chgline(char x)
{
  send_i(CURMOV);
  send_i(x);
}

/*
***********************************************************************
  print_c: Print (single) character x on LCD            
***********************************************************************
*/
 
void print_c(char x)
{
  RSON;
  send_byte(x);
}

/*
***********************************************************************
  pmsglcd: print character string str[] on LCD
***********************************************************************
*/

void pmsglcd(char str[])
{
  int j = 0;
  while(str[j] != '\0') 
  {
    print_c(str[j]);
    j++;
  }
}

/*
***********************************************************************
 Character I/O Library Routines for 9S12C32 
***********************************************************************
 Name:         inchar
 Description:  inputs ASCII character from SCI serial port and returns it
 Example:      char ch1 = inchar();
***********************************************************************
*/

char inchar(void) {
  /* receives character from the terminal channel */
        while (!(SCISR1 & 0x20)); /* wait for input */
    return SCIDRL;
}

/*
***********************************************************************
 Name:         outchar    (use only for DEBUGGING purposes)
 Description:  outputs ASCII character x to SCI serial port
 Example:      outchar('x');
***********************************************************************
*/

void outchar(char x) {
  /* sends a character to the terminal channel */
    while (!(SCISR1 & 0x80));  /* wait for output buffer empty */
    SCIDRL = x;
}